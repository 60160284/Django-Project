Bambo House

I thank you for download my model. Please buy my cheap model to thank me. In future 
I will be prepar another collection. I share with you other free models.
Your shopping help me develop self.

Link:

http://www.turbosquid.com/Search/Artists/TomaszCGB

Textures:
https://drive.google.com/?authuser=0#folders/0B3RbBF2m8FWhdUJ4ZTJrSnFVcDA

Very simple but detail model for vizualization.

Archive contain: 
-high quality textures,
fbx format,
-obj format,
-materials ,
-high quality model,

House can be use for architectual vizualization, background, model for game, and much more.

Buy all collection:
http://3dexport.com/3dmodel-collectionhouses-84468.htm
